#include <stdio.h>         
#include <stdlib.h>        
#include <string.h>       
#include <unistd.h>        
#include <sys/epoll.h>      
#include <sys/socket.h>     
#include <sys/un.h>         
#include <sys/ioctl.h>      
#include <netpacket/packet.h> 
#include <net/ethernet.h>  
#include <net/if.h>          
#include <ifaddrs.h>       

#include "mipd.h"
#include "pdu.h"
#include "arp.h"
#include "routingd.h"
#include "iface.h"
#include "queue.h"
#include "unix.h"
#include "raw_handler.h"

int debug_mode = 0; // globalt debug flagg
int my_mip_address = -1; // min mip addresse

/*
    Denne funksjonen starter MIP-daemonen. 
    MIP-deamonen skal fungere som et mellomledd mellom unix klienter og nettverket

    Den håndterer flaggene -h og -d, henter inn socket-sti og MIP-adresse fra argumentene,
    finner nettverksinterface og oppretter både UNIX- og råsocket

    Disse legges i en epoll-instans, og programmet går deretter i en løkke som behandler 
    enten klientforespørsler eller mottatte MIP-pakker samtidig

    Når en klient kobler seg til, registreres den i en klienttabell. 
    Når en pakke kommer inn fra nettverket, sendes den videre til riktig UNIX-klient, og motsatt

 */

int main(int argc, char *argv[]) {

    // Håndterer -h og -d
    // getopt() returnerer flagg-bokstaven som en char eller -1 når det ikke er flere flagg
    int opt;
    while ((opt = getopt(argc, argv, "hd")) != -1) {
        switch(opt) {
            case 'h':
                printf("Usage: %s [-d] <socket_upper> <MIP address>\n", argv[0]);
                printf("Options:\n");
                printf("  -h print help and exit\n");
                printf("  -d enable debug mode\n");
                return 0;
            case 'd':
                debug_mode = 1;
                break;
            default:
                //stderr skriver til standard error
                fprintf(stderr, "Unknown option\n");
                return 1;
        }
    }

    // Sørger for linjebuffering på stdout/stderr (for jevn logging i flere terminaler)
    setvbuf(stdout, NULL, _IOLBF, 0);
    setvbuf(stderr, NULL, _IOLBF, 0);
    dup2(fileno(stdout), fileno(stderr));

    //sjekker at argumentene gis riktig, avslutter hvis det ikke finnes minst 2, socket og mip addresse
    if (optind + 2 > argc) {
        fprintf(stderr, "Usage: %s [-d] <socket_upper> <MIP address>\n", argv[0]);
        exit(EXIT_FAILURE);
    }
    
    // Leser inn UNIX socketsti og MIP-adresse
    char *socket_path = argv[optind];
    my_mip_address = atoi(argv[optind+1]);

    //Henter grensesnitt og initier ARP-cache
    find_all_ifaces();
    arp_init_cache();

    
    if(debug_mode){
        printf("[DEBUG] Interfaces found at startup:\n");

        for (int i = 0; i < iface_count; i++) {
            printf("   iface[%d] = %s (index=%d)\n",
                i, iface_name[i], iface_indices[i]);
        }
    }

    if (debug_mode) {
        printf("[DEBUG] Starting MIP daemon on UNIX socket '%s' with MIP address %d\n",
               socket_path, my_mip_address);
        printf("[DEBUG] Initial ARP cache:\n");
        print_arp_cache();
    }

    // Opprett UNIX- og RAW-socket
    int unix_sock = create_unix_socket(socket_path); //lytte socket
    int raw_sock = create_raw_socket();

    // oppretter en epoll instans
    // Epoll instans er en beholder som kan overvåle flere fildeskriptorer samtidig
    int epollfd = epoll_create1(0);

    if (epollfd == -1) {
        perror("epoll_create1");
        exit(EXIT_FAILURE);
    }

    //ev brukes til å registrere en enkelt socket
    //events er et array av hendelser som epoll_wait() returnerer og forteller hvilke
    //sockets som har tilgjengelig data
    struct epoll_event ev, events[MAX_EVENTS];

    // Registrer UNIX-socket
    ev.events = EPOLLIN; // ønsker å overvåke innkommende data
    ev.data.fd = unix_sock; //fil deskriptor til epoll for å vite hvilken socket det er snakk om

    //legger til instansen i epollfd (instansen fra tidligere)
    // EPOLL_CTL_ADD forteller instansen at socketen skal overvåkes
    if (epoll_ctl(epollfd, EPOLL_CTL_ADD, unix_sock, &ev) == -1) {
        perror("epoll_ctl: unix_sock");
        exit(EXIT_FAILURE);
    }

    // Registrer RAW-socket
    ev.events = EPOLLIN; // ønsker å overvåke innkommende data
    ev.data.fd = raw_sock; //fil deskriptor til epoll for å vite hvilken socket det er snakk om
    
    //samme som med unix socket
    if (epoll_ctl(epollfd, EPOLL_CTL_ADD, raw_sock, &ev) == -1) {
        perror("epoll_ctl: raw_sock");
        exit(EXIT_FAILURE);
    }

    printf("Daemon running. Listening on UNIX + RAW sockets...\n");


    // Hovedløkken – overvåker sockets og fordeler hendelser
    while (1) {
        // epoll.wait() venter på at en av de registrerte socketene får innkommende data
        // nfds holder verdien i int for hvor mange sockets som har hendelser
        int nfds = epoll_wait(epollfd, events, MAX_EVENTS, -1);
    
        if (nfds == -1) {
            perror("epoll_wait");
            exit(EXIT_FAILURE);
        }

        for(int n = 0; n < nfds; n++){
            int fd = events[n].data.fd;

            // Ny UNIX-klient kobler seg til mipd
            if (fd == unix_sock){
                int client_fd = accept(unix_sock, NULL, NULL);
                if (client_fd == -1) {
                    perror("accept");
                    continue;
                }

                // Klienten sender SDU-type som første byte
                uint8_t sdu_type;
                if(read(client_fd, &sdu_type, 1) != 1) {
                    perror("read sdu type");
                    close(client_fd);
                    continue;
                }

                // Hvis klienten er routingd, send tilbake min MIP-adresse
                if (sdu_type == SDU_TYPE_ROUTING) {
                    uint8_t mip_addr = (uint8_t) my_mip_address;
                    if (write(client_fd, &mip_addr, 1) != 1) {
                        perror("[MIPD] failed to send my_mip_address to routingd");
                    } else if (debug_mode) {
                        printf("[MIPD] Sent my MIP address (%d) to routingd\n", mip_addr);
                    }
                }

                // Registrer ny klient i tabellen
                for (int i = 0; i < MAX_UNIX_CLIENT; i++) {
                    if (!unix_clients[i].active) {
                        unix_clients[i].fd = client_fd;
                        unix_clients[i].sdu_type = sdu_type;
                        unix_clients[i].active = 1;
                        if (debug_mode)
                            printf("[UNIX] New client registered: fd=%d, sdu_type=0x%02X\n",
                                   client_fd, sdu_type);
                        break;
                    }
                }

                // Legger klienten inn i epoll slik at man kan lese meldinger senere
                ev.events = EPOLLIN;
                ev.data.fd = client_fd;
                if (epoll_ctl(epollfd, EPOLL_CTL_ADD, client_fd, &ev) == -1) {
                    perror("epoll_ctl: client_fd");
                    close(client_fd);
                    continue;
                }
            }

            // Mottatt pakke fra nettverket via RAW-socket
            else if(fd == raw_sock) {
                handle_raw_packet(raw_sock, my_mip_address); //håndterer meldingen videre
            }

            //Data mottatt fra en aktiv UNIX-klient
            else {
                for (int i = 0; i < MAX_UNIX_CLIENT; i++) {
                    if (unix_clients[i].active && unix_clients[i].fd == fd) {
                        if (debug_mode) {
                            printf("[DEBUG][EPOLL] Activity on fd=%d (type=0x%02X)\n",
                                fd, unix_clients[i].sdu_type);
                            fflush(stdout);
                        }
                        break;
                    }
                }
                // Håndterer meldingen
                handle_unix_request(fd, raw_sock, my_mip_address);
            }
        }
    }
    //ferdig - lukker socketene
    close(unix_sock);
    close(raw_sock);
    return 0;
}

